<?php

require_once __DIR__ . '/../config.php';

class Reclamation
{
    private ?int $id_reclamation = null;
    private ?string $nom = null;
    private ?string $mail = null;
    private ?string $description = null;
    private ?string $date_creation = null;
    private ?string $statut = null;

    // Constructeur
    public function __construct(?int $id_reclamation = null, ?string $nom = null, ?string $mail = null, ?string $description = null, ?string $statut = null)
    {
        $this->id_reclamation = $id_reclamation;
        $this->nom = $nom;
        $this->mail = $mail;
        $this->description = $description;
        $this->statut = $statut;
    }

    // Getters
    public function getIdReclamation(): ?int
    {
        return $this->id_reclamation;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function getMail(): ?string
    {
        return $this->mail;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function getDateCreation(): ?string
    {
        return $this->date_creation;
    }

    public function getStatut(): ?string
    {
        return $this->statut;
    }

    // Setters
    public function setIdReclamation(?int $id_reclamation): void
    {
        $this->id_reclamation = $id_reclamation;
    }

    public function setNom(?string $nom): void
    {
        $this->nom = $nom;
    }

    public function setMail(?string $mail): void
    {
        $this->mail = $mail;
    }

    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    public function setDateCreation(?string $date_creation): void
    {
        $this->date_creation = $date_creation;
    }

    public function setStatut(?string $statut): void
    {
        $this->statut = $statut;
    }

    // Récupérer toutes les réclamations
    public function findAll(): array
    {
        $sql = "SELECT * FROM reclamation ORDER BY date_creation DESC";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    // Ajouter une réclamation
    public function add(Reclamation $reclamation): void
    {
        $sql = "INSERT INTO reclamation (nom, mail, description, statut) VALUES (:nom, :mail, :description, :statut)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'nom' => $reclamation->getNom(),
                'mail' => $reclamation->getMail(),
                'description' => $reclamation->getDescription(),
                'statut' => $reclamation->getStatut()
            ]);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    // Supprimer une réclamation
    public function delete(int $id): void
    {
        $sql = "DELETE FROM reclamation WHERE id_reclamation = :id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute(['id' => $id]);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    // Récupérer une réclamation par ID
    public function findById(int $id): ?array
    {
        $sql = "SELECT * FROM reclamation WHERE id_reclamation = :id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute(['id' => $id]);
            return $query->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    // Modifier une réclamation
    public function update(Reclamation $reclamation): void
    {
        $sql = "UPDATE reclamation SET nom = :nom, mail = :mail, description = :description, statut = :statut WHERE id_reclamation = :id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'id' => $reclamation->getIdReclamation(),
                'nom' => $reclamation->getNom(),
                'mail' => $reclamation->getMail(),
                'description' => $reclamation->getDescription(),
                'statut' => $reclamation->getStatut()
            ]);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
}
