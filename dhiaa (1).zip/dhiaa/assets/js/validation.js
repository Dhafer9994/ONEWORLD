// Validation pour le formulaire de réclamation

// Fonction pour afficher les erreurs
function showError(input, message) {
    const formGroup = input.parentElement;
    let errorDiv = formGroup.querySelector('.error-message');
    
    if (!errorDiv) {
        errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        formGroup.appendChild(errorDiv);
    }
    
    errorDiv.textContent = message;
    input.classList.add('error');
}

// Fonction pour effacer les erreurs
function clearError(input) {
    const formGroup = input.parentElement;
    const errorDiv = formGroup.querySelector('.error-message');
    
    if (errorDiv) {
        errorDiv.remove();
    }
    
    input.classList.remove('error');
}

// Validation du nom
function validateNom(nom) {
    clearError(nom);
    const value = nom.value.trim();
    
    if (value === '') {
        showError(nom, 'Le nom est obligatoire');
        return false;
    }
    
    if (value.length < 3) {
        showError(nom, 'Le nom doit contenir au moins 3 caractères');
        return false;
    }
    
    if (value.length > 50) {
        showError(nom, 'Le nom ne doit pas dépasser 50 caractères');
        return false;
    }
    
    // Vérifier que le nom contient uniquement des lettres, espaces et tirets
    const nameRegex = /^[a-zA-ZÀ-ÿ\s-]+$/;
    if (!nameRegex.test(value)) {
        showError(nom, 'Le nom ne doit contenir que des lettres, espaces et tirets');
        return false;
    }
    
    return true;
}

// Validation de l'email
function validateMail(mail) {
    clearError(mail);
    const value = mail.value.trim();
    
    if (value === '') {
        showError(mail, 'L\'email est obligatoire');
        return false;
    }
    
    // Regex pour valider le format email
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(value)) {
        showError(mail, 'Format d\'email invalide (exemple: nom@domaine.com)');
        return false;
    }
    
    if (value.length > 100) {
        showError(mail, 'L\'email ne doit pas dépasser 100 caractères');
        return false;
    }
    
    return true;
}

// Validation de la description
function validateDescription(description) {
    clearError(description);
    const value = description.value.trim();
    
    if (value === '') {
        showError(description, 'La description est obligatoire');
        return false;
    }
    
    if (value.length < 10) {
        showError(description, 'La description doit contenir au moins 10 caractères');
        return false;
    }
    
    if (value.length > 500) {
        showError(description, 'La description ne doit pas dépasser 500 caractères');
        return false;
    }
    
    return true;
}

// Validation du statut
function validateStatut(statut) {
    clearError(statut);
    const value = statut.value;
    
    if (value === '') {
        showError(statut, 'Le statut est obligatoire');
        return false;
    }
    
    const validStatuts = ['En attente', 'Traitée', 'Rejetée'];
    if (!validStatuts.includes(value)) {
        showError(statut, 'Statut invalide');
        return false;
    }
    
    return true;
}

// Validation en temps réel
function setupRealtimeValidation() {
    const nomInput = document.getElementById('nom');
    const mailInput = document.getElementById('mail');
    const descriptionInput = document.getElementById('description');
    const statutInput = document.getElementById('statut');
    
    if (nomInput) {
        nomInput.addEventListener('blur', function() {
            validateNom(this);
        });
        
        nomInput.addEventListener('input', function() {
            if (this.classList.contains('error')) {
                validateNom(this);
            }
        });
    }
    
    if (mailInput) {
        mailInput.addEventListener('blur', function() {
            validateMail(this);
        });
        
        mailInput.addEventListener('input', function() {
            if (this.classList.contains('error')) {
                validateMail(this);
            }
        });
    }
    
    if (descriptionInput) {
        descriptionInput.addEventListener('blur', function() {
            validateDescription(this);
        });
        
        descriptionInput.addEventListener('input', function() {
            if (this.classList.contains('error')) {
                validateDescription(this);
            }
            
            // Afficher le compteur de caractères
            const counter = this.parentElement.querySelector('.char-counter');
            if (counter) {
                const length = this.value.length;
                counter.textContent = `${length}/500 caractères`;
                
                if (length > 500) {
                    counter.style.color = '#dc3545';
                } else if (length >= 400) {
                    counter.style.color = '#ffc107';
                } else {
                    counter.style.color = '#6c757d';
                }
            }
        });
    }
    
    if (statutInput) {
        statutInput.addEventListener('change', function() {
            validateStatut(this);
        });
    }
}

// Validation complète du formulaire
function validateForm(event) {
    event.preventDefault();
    
    const form = event.target;
    const nomInput = form.querySelector('#nom');
    const mailInput = form.querySelector('#mail');
    const descriptionInput = form.querySelector('#description');
    const statutInput = form.querySelector('#statut');
    
    let isValid = true;
    
    // Valider tous les champs
    if (nomInput && !validateNom(nomInput)) {
        isValid = false;
    }
    
    if (mailInput && !validateMail(mailInput)) {
        isValid = false;
    }
    
    if (descriptionInput && !validateDescription(descriptionInput)) {
        isValid = false;
    }
    
    if (statutInput && !validateStatut(statutInput)) {
        isValid = false;
    }
    
    // Si tout est valide, soumettre le formulaire
    if (isValid) {
        form.submit();
    } else {
        // Faire défiler vers la première erreur
        const firstError = form.querySelector('.error');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            firstError.focus();
        }
    }
}

// Initialiser la validation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('.form');
    
    if (form) {
        // Désactiver la validation HTML5
        form.setAttribute('novalidate', 'novalidate');
        
        // Ajouter l'écouteur de soumission
        form.addEventListener('submit', validateForm);
        
        // Configurer la validation en temps réel
        setupRealtimeValidation();
        
        // Ajouter un compteur de caractères pour la description
        const descriptionInput = document.getElementById('description');
        if (descriptionInput) {
            const counter = document.createElement('div');
            counter.className = 'char-counter';
            counter.textContent = '0/500 caractères';
            descriptionInput.parentElement.appendChild(counter);
        }
    }
});
