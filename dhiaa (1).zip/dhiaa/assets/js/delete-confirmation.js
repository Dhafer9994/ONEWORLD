// Gestion de la suppression avec icônes de confirmation

document.addEventListener('DOMContentLoaded', function() {
    const deleteButtons = document.querySelectorAll('.delete-btn');
    
    deleteButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const actionsCell = this.parentElement;
            const row = this.closest('tr');
            
            // Cacher les boutons modifier et supprimer
            const editBtn = actionsCell.querySelector('.btn-success');
            const deleteBtn = this;
            const confirmBtn = actionsCell.querySelector('.confirm-btn[data-id="' + id + '"]');
            const cancelBtn = actionsCell.querySelector('.cancel-btn[data-id="' + id + '"]');
            
            // Animation de disparition
            editBtn.style.animation = 'fadeOut 0.3s ease';
            deleteBtn.style.animation = 'fadeOut 0.3s ease';
            
            setTimeout(() => {
                editBtn.style.display = 'none';
                deleteBtn.style.display = 'none';
                
                // Afficher les boutons de confirmation avec animation
                confirmBtn.style.display = 'inline-flex';
                cancelBtn.style.display = 'inline-flex';
                confirmBtn.style.animation = 'fadeIn 0.3s ease';
                cancelBtn.style.animation = 'fadeIn 0.3s ease';
                
                // Mettre en surbrillance la ligne
                row.style.backgroundColor = '#fff5f5';
                row.style.border = '2px solid #dc3545';
                row.style.transform = 'scale(1.02)';
            }, 300);
        });
    });
    
    // Gérer les boutons de confirmation
    const confirmButtons = document.querySelectorAll('.confirm-btn');
    confirmButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const row = this.closest('tr');
            
            // Animation de suppression
            row.style.animation = 'slideOutRight 0.5s ease';
            
            setTimeout(() => {
                window.location.href = `index.php?action=delete&id=${id}`;
            }, 500);
        });
    });
    
    // Gérer les boutons d'annulation
    const cancelButtons = document.querySelectorAll('.cancel-btn');
    cancelButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const actionsCell = this.parentElement;
            const row = this.closest('tr');
            
            // Cacher les boutons de confirmation
            const confirmBtn = actionsCell.querySelector('.confirm-btn[data-id="' + id + '"]');
            const cancelBtn = this;
            const editBtn = actionsCell.querySelector('.btn-success');
            const deleteBtn = actionsCell.querySelector('.delete-btn[data-id="' + id + '"]');
            
            // Animation de disparition
            confirmBtn.style.animation = 'fadeOut 0.3s ease';
            cancelBtn.style.animation = 'fadeOut 0.3s ease';
            
            setTimeout(() => {
                confirmBtn.style.display = 'none';
                cancelBtn.style.display = 'none';
                
                // Réafficher les boutons originaux
                editBtn.style.display = 'inline-flex';
                deleteBtn.style.display = 'inline-flex';
                editBtn.style.animation = 'fadeIn 0.3s ease';
                deleteBtn.style.animation = 'fadeIn 0.3s ease';
                
                // Retirer la surbrillance
                row.style.backgroundColor = '';
                row.style.border = '';
                row.style.transform = '';
            }, 300);
        });
    });
    
    // Animation au survol des lignes du tableau
    const tableRows = document.querySelectorAll('.table tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            if (!this.style.border) {
                this.style.transform = 'scale(1.01)';
            }
        });
        
        row.addEventListener('mouseleave', function() {
            if (!this.style.border) {
                this.style.transform = 'scale(1)';
            }
        });
    });
});

// Ajouter les animations CSS dynamiquement
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeOut {
        from { opacity: 1; transform: scale(1); }
        to { opacity: 0; transform: scale(0.8); }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: scale(0.8); }
        to { opacity: 1; transform: scale(1); }
    }
    
    @keyframes slideOutRight {
        from { 
            opacity: 1; 
            transform: translateX(0);
        }
        to { 
            opacity: 0; 
            transform: translateX(100%);
        }
    }
`;
document.head.appendChild(style);
