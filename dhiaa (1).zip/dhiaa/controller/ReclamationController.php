<?php

require_once __DIR__ . '/../model/Reclamation.php';

class ReclamationController
{
    // Afficher la liste des réclamations
    public function listReclamations(): void
    {
        $reclamation = new Reclamation();
        $list = $reclamation->findAll();
        require_once __DIR__ . '/../view/listReclamation.php';
    }

    // Afficher le formulaire d'ajout
    public function showAddForm(): void
    {
        require_once __DIR__ . '/../view/addReclamation.php';
    }

    // Ajouter une réclamation
    public function addReclamation(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $reclamation = new Reclamation();
            $newReclamation = new Reclamation(
                null,
                $_POST['nom'],
                $_POST['mail'],
                $_POST['description'],
                $_POST['statut']
            );
            $reclamation->add($newReclamation);
            header('Location: index.php');
            exit();
        }
    }

    // Afficher le formulaire de modification
    public function showEditForm(int $id): void
    {
        $reclamation = new Reclamation();
        $rec = $reclamation->findById($id);
        require_once __DIR__ . '/../view/editReclamation.php';
    }

    // Modifier une réclamation
    public function updateReclamation(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $reclamation = new Reclamation();
            $updatedReclamation = new Reclamation(
                (int)$_POST['id_reclamation'],
                $_POST['nom'],
                $_POST['mail'],
                $_POST['description'],
                $_POST['statut']
            );
            $reclamation->update($updatedReclamation);
            header('Location: index.php');
            exit();
        }
    }

    // Supprimer une réclamation
    public function deleteReclamation(int $id): void
    {
        $reclamation = new Reclamation();
        $reclamation->delete($id);
        header('Location: index.php');
        exit();
    }
}
