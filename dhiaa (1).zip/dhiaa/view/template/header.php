<header class="header">
    <div class="header-container">
        <div class="logo">
            <i class="fas fa-clipboard-list"></i>
            <span>Gestion Réclamations</span>
        </div>
        <nav class="nav">
            <a href="index.php" class="nav-link active">
                <i class="fas fa-home"></i> Accueil
            </a>
            <a href="index.php?action=add" class="nav-link">
                <i class="fas fa-plus"></i> Nouvelle Réclamation
            </a>
        </nav>
    </div>
</header>
