<footer class="footer">
    <div class="footer-container">
        <p>&copy; <?= date('Y') ?> Gestion des Réclamations. Tous droits réservés.</p>
        <p>Développé avec <i class="fas fa-heart" style="color: #e74c3c;"></i></p>
    </div>
</footer>
