<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Réclamations</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>
<body>
    <?php include 'template/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-exclamation-circle"></i> Gestion des Réclamations</h1>
            <a href="index.php?action=add" class="btn btn-primary">
                <i class="fas fa-plus"></i> Nouvelle Réclamation
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <?php if (empty($list)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>Aucune réclamation trouvée</p>
                    </div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nom</th>
                                <th>Email</th>
                                <th>Description</th>
                                <th>Date de Création</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($list as $reclamation): ?>
                                <tr>
                                    <td><?= htmlspecialchars($reclamation['id_reclamation']) ?></td>
                                    <td><?= htmlspecialchars($reclamation['nom']) ?></td>
                                    <td><?= htmlspecialchars($reclamation['mail']) ?></td>
                                    <td class="description-cell">
                                        <?= htmlspecialchars(substr($reclamation['description'], 0, 100)) ?>
                                        <?= strlen($reclamation['description']) > 100 ? '...' : '' ?>
                                    </td>
                                    <td><?= htmlspecialchars($reclamation['date_creation']) ?></td>
                                    <td>
                                        <?php
                                            $badgeClass = 'warning';
                                            if ($reclamation['statut'] === 'Traitée') {
                                                $badgeClass = 'success';
                                            } elseif ($reclamation['statut'] === 'Rejetée') {
                                                $badgeClass = 'danger';
                                            }
                                        ?>
                                        <span class="badge badge-<?= $badgeClass ?>">
                                            <?= htmlspecialchars($reclamation['statut']) ?>
                                        </span>
                                    </td>
                                    <td class="actions">
                                        <a href="index.php?action=edit&id=<?= $reclamation['id_reclamation'] ?>" 
                                           class="btn btn-sm btn-success" title="Modifier">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button class="btn btn-sm btn-danger delete-btn" 
                                                data-id="<?= $reclamation['id_reclamation'] ?>"
                                                title="Supprimer">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        <button class="btn btn-sm btn-success confirm-btn" 
                                                data-id="<?= $reclamation['id_reclamation'] ?>"
                                                style="display: none;"
                                                title="Confirmer">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button class="btn btn-sm btn-secondary cancel-btn" 
                                                data-id="<?= $reclamation['id_reclamation'] ?>"
                                                style="display: none;"
                                                title="Annuler">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'template/footer.php'; ?>
    <script src="assets/js/delete-confirmation.js"></script>
</body>
</html>
