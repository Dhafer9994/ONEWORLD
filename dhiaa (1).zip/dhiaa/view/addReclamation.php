<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Réclamation</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>
<body>
    <?php include 'template/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-plus-circle"></i> Ajouter une Réclamation</h1>
        </div>

        <div class="card">
            <div class="card-body">
                <form action="index.php?action=add" method="POST" class="form">
                    <div class="form-group">
                        <label for="nom">
                            <i class="fas fa-user"></i> Nom
                        </label>
                        <input type="text" id="nom" name="nom" class="form-control" placeholder="Nom complet">
                    </div>

                    <div class="form-group">
                        <label for="mail">
                            <i class="fas fa-envelope"></i> Email
                        </label>
                        <input type="text" id="mail" name="mail" class="form-control" placeholder="exemple@email.com">
                    </div>

                    <div class="form-group">
                        <label for="description">
                            <i class="fas fa-align-left"></i> Description
                        </label>
                        <textarea id="description" name="description" class="form-control" rows="6" placeholder="Décrivez votre réclamation..."></textarea>
                    </div>

                    <div class="form-group">
                        <label for="statut">
                            <i class="fas fa-tag"></i> Statut
                        </label>
                        <select id="statut" name="statut" class="form-control">
                            <option value="En attente">En attente</option>
                            <option value="Traitée">Traitée</option>
                            <option value="Rejetée">Rejetée</option>
                        </select>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Enregistrer
                        </button>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Annuler
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include 'template/footer.php'; ?>
    <script src="assets/js/validation.js"></script>
</body>
</html>
