<?php

require_once __DIR__ . '/controller/ReclamationController.php';

$controller = new ReclamationController();

$action = $_GET['action'] ?? 'list';

switch ($action) {
    case 'list':
        $controller->listReclamations();
        break;

    case 'add':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->addReclamation();
        } else {
            $controller->showAddForm();
        }
        break;

    case 'edit':
        if (isset($_GET['id'])) {
            $controller->showEditForm((int)$_GET['id']);
        } else {
            header('Location: index.php');
            exit();
        }
        break;

    case 'update':
        $controller->updateReclamation();
        break;

    case 'delete':
        if (isset($_GET['id'])) {
            $controller->deleteReclamation((int)$_GET['id']);
        } else {
            header('Location: index.php');
            exit();
        }
        break;

    default:
        $controller->listReclamations();
        break;
}
